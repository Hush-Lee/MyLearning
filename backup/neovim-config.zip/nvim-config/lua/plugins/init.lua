return {
  { "catppuccin/nvim", name = "catppuccin", priority = 1000, config = function()
      vim.cmd.colorscheme("catppuccin-mocha")
    end,
  },
  { "nvim-tree/nvim-web-devicons", lazy = true },
  { "nvim-tree/nvim-tree.lua", config = function() require("nvim-tree").setup({}) end },
  { "nvim-lualine/lualine.nvim", dependencies = { "nvim-tree/nvim-web-devicons" },
    config = function() require("lualine").setup({ options = { theme = "catppuccin" } }) end },
  { "goolord/alpha-nvim", config = function() require("alpha").setup(require("alpha.themes.dashboard").config) end },
  { "akinsho/bufferline.nvim", version = "*", dependencies = "nvim-tree/nvim-web-devicons",
    config = function() require("bufferline").setup({}) end },
  { "hrsh7th/nvim-cmp" }, { "hrsh7th/cmp-nvim-lsp" }, { "hrsh7th/cmp-buffer" },
  { "hrsh7th/cmp-path" }, { "hrsh7th/cmp-cmdline" }, { "saadparwaiz1/cmp_luasnip" },
  { "L3MON4D3/LuaSnip" }, { "rafamadriz/friendly-snippets" },
  { "neovim/nvim-lspconfig" }, { "williamboman/mason.nvim" }, { "williamboman/mason-lspconfig.nvim" },
  { "windwp/nvim-autopairs", event = "InsertEnter", config = function()
      require("nvim-autopairs").setup()
      local cmp_autopairs = require("nvim-autopairs.completion.cmp")
      local cmp = require("cmp")
      cmp.event:on("confirm_done", cmp_autopairs.on_confirm_done())
    end },
  { "folke/noice.nvim", dependencies = { "MunifTanjim/nui.nvim" }, config = true },
  { "echasnovski/mini.animate", version = "*", config = true },
}